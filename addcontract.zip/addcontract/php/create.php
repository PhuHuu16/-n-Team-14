<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Thêm sinh viên</title>
    <link rel="stylesheet" href="../index.css">
</head>
<body>
    <div class="img"><img src="../img/u4.png" alt=""></div>
    <div class="container">
        <h3 class="title">Thêm hợp đồng thanh toán</h3>
        <form method="post">
            <div>
                <label for="hovaten">Họ và tên người mua:</label>
                <input type="text" name="hovaten">
            </div>
            <div>
                <label for=" sinhnam">Sinh năm</label>
                <input type="text" name="sinhnam">
            </div>
            <div>
                <label for="cccd">CCCD</label>
                <input type="text" name="cccd">
            </div>
            <div>
                <label for="diachi">Địa chỉ</label>
                <input type="text" name="diachi">
            </div>
            <div>
                <label for="sodienthoai">Số điện thoại</label>
                <input type="text" name="sodienthoai">
            </div>
            <div>
                <label for="ngaylaphopdong">Ngày lập hợp đồng:</label>
                <input type="text" name="ngaylaphopdong" placeholder="VD:26/11/2023">
            </div>
            <div>
                <label for="giatrihopdong">Giá trị hợp đồng</label>
                <input type="text" name="giatrihopdong">
            </div>
            <div>
                <label for="sotiendacoc">Số tiền đã cọc</label>
                <input type="text" name="sotiendacoc">
            </div>
            <div>
                <label for="sotienconlai">Số tiền còn lại</label>
                <input type="text" name="sotienconlai">
            </div>
            <div>
                <label for="trangthai">Trạng thái:</label>
                <select name="trangthai" id="cars">
                    <option value="Thanh Toán Một Lần">Thanh toán một lần</option>
                    <option value="Thanh Toán Trả Góp">Thanh toán trả góp</option>
                </select>
            </div>
            <input type="submit" name="submit" value="Thêm mới">
            <a href="../index.php"><input type="button" value="Hủy" class="cancel"></a>
        </form>
    </div>
    <?php
        include("connect.php");
        //Xử lý dữ liệu submit bằng phương thức POST của người dùng
        if (isset($_POST['submit'])) {
            $hovaten = $_POST['hovaten'];
            $sinhnam = $_POST['sinhnam'];
            $cccd = $_POST['cccd'];
            $diachi = $_POST['diachi'];
            $sodienthoai = $_POST['sodienthoai'];
            $ngaylaphopdong = $_POST['ngaylaphopdong'];
            $giatrihopdong = $_POST['giatrihopdong'];
            $sotiendacoc = $_POST['sotiendacoc'];
            $sotienconlai = $_POST['sotienconlai'];
            $trangthai=$_POST['trangthai'];

            //Câu lệnh insert
            $sql = "INSERT INTO addcontract(hovaten, sinhnam, cccd, diachi, sodienthoai, ngaylaphopdong, giatrihopdong, sotiendacoc, sotienconlai, trangthai)
        VALUES('$hovaten', $sinhnam, $cccd, '$diachi', '$sodienthoai', '$ngaylaphopdong', '$giatrihopdong', '$sotiendacoc', '$sotienconlai', '$trangthai')";
            //Thực thi câu lệnh SQL
            $result = $conn->query($sql);
            //Kiểm tra lỗi
            if(!$result){
                die("Lỗi kết nối: " . $conn->connect_error);
            }
            //Chuyển tiếp về trang index khi thêm mới thành công
            header("location: ../index.php");
            exit;
        }
    ?>
        <div id="u1" class="ax_default box_1">
        <div id="u1_text" class="text ">
        <p><span>@Copyright by Pass Subject Together</span></p>
        </div>
    </div>
</body>
</html>
