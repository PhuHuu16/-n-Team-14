<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="index.css">
    <title>View List Contract</title>
</head>
<body>
    <div class="logo"><img src="img/u4.png" alt=""></div>
    <div class="container">
        <h3 class="title"> DANH SÁCH HỢP ĐỒNG THANH TOÁN </h3>
        <a class="submit" href="php/create.php">Thêm hợp đồng</a>
        <div class="table">
            <table>
                <thead>
                    <tr>
                        <th>Mã hợp đồng</th>
                        <th>Tên người mua</th>
                        <th>Địa chỉ</th>
                        <th>Trạng thái</th>
                        <th>Hành động</th>
                    </tr>
                </thead>
                <tbody id="contract-list">
                <?php
                    //Kết nối CSDL
                    include("php/connect.php");
                    //Câu lệnh select
                    $sql = "SELECT * FROM addcontract";
                    $result = $conn->query($sql);   
                    //Đổ dữ liệu lên bảng
                    if ($result->num_rows > 0) {
                        while ($row = $result->fetch_assoc()) {
                            echo"
                                <tr>
                                    <td>HD".$row['id']."</td>
                                    <td>$row[hovaten]</td>
                                    <td>$row[diachi]</td>
                                    <td>$row[trangthai]</td>
                                    <td>
                                    <a class='btn danger' style='margin-right: 0;'href='php/delete.php?id=$row[id]'>Xóa</a>
                                    </td>
                                </tr>
                            ";
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
    <div id="u1" class="ax_default box_1">
        <div id="u1_text" class="text ">
        <p><span>@Copyright by Pass Subject Together</span></p>
        </div>
    </div>
</body>
</html>